"""Drone integration: camera tracking + dodging -> velocity commands for a flight controller,
with an optional 6-nozzle cold-gas assist. Uses the same gnc/ guidance as the table platform."""
